var currentArray = [];

function GetArray(timeOfDay)
{
	//lat: 56.46006773284139, lng: -2.9729378344516486, alt: 3.2812469117343426}

	//take from js [2] [3] [4] 


	
	return currentArray;
}